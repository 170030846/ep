import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class RemarksInsert extends HttpServlet
{
	public void service(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
               {
		   PrintWriter out=res.getWriter();
                    res.setContentType("text/html");
                    try{
		
                    String Username =req.getParameter("uname");
                    String remarks =req.getParameter("remarks");        
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","manager");

                        

			PreparedStatement pstmt=con.prepareStatement("insert into farewell values(?,?)");
                         pstmt.setString(1,Username);
                         pstmt.setString(2,remarks);
                          int i=  pstmt.executeUpdate();
                          
                           if(i!=0)
                                   {

				out.println("Remarks are succssfully submitted");
		                    }
              

                           else
                           {
                           out.println("You failed submit the remarks");
                           } 
                           }

                         catch(Exception e){
			out.println(e);
		}
	}
}
