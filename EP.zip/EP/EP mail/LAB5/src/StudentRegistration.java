import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class StudentRegistration extends HttpServlet
{
	public void service(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
               {
		   PrintWriter out=res.getWriter();
                    res.setContentType("text/html");
                    try{
		
                    String name=req.getParameter("name");
                    String id=req.getParameter("id");
                    String Username =req.getParameter("uname");
                    String pwd=req.getParameter("pwd");
                   String email=req.getParameter("email");
                   String contact=req.getParameter("num");
                
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","manager");

                        

			PreparedStatement pstmt=con.prepareStatement("insert into Registeredmembers values(?,?,?,?,?,?)");
                         pstmt.setString(1,name);
                         pstmt.setString(2,id);
                         pstmt.setString(3,Username);
                         pstmt.setString(4,pwd);
                         pstmt.setString(5,email);
                         pstmt.setString(6,contact);
                          int i=  pstmt.executeUpdate();
                          
                           if(i!=0)
                                   {

				out.println("Your successfully Registerd");
		                    }
              

                           else
                           {
                           out.println("You failed to register");
                           } 
}

                         catch(Exception e){
			out.println(e);
		}
	}
}
