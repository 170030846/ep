import java.sql.*;
import java.util.*;
class 	Inlab4_3A
{
public static void main(String [] args) throws Exception
{
Class.forName("oracle.jdbc.driver.OracleDriver");
Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","manager");
Statement stmt=con.createStatement();
stmt.executeUpdate("create table workshop(id number,contactnumber varchar2(20),name varchar2(20),email varchar2(30))");
stmt.executeUpdate("alter table workshop add foreign key(id) references student(student_id)");
Scanner sc=new Scanner(System.in);
System.out.println("Enter number of students intrested");
int n=sc.nextInt();
for(int i=0;i<n;i++)
{
System.out.println("Enter ID number");
int id=sc.nextInt();
System.out.println("Enter your contact number");
String co=sc.next();
PreparedStatement pstmt=con.prepareStatement("insert into workshop(id,contactnumber) values(?,?)");
pstmt.setInt(1,id);
pstmt.setString(2,co);
pstmt.executeUpdate();
}

stmt.close();
con.close();
}
}