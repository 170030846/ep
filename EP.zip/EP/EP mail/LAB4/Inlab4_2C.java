import java.sql.*;
import java.util.*;
class Inlab4_2C
{
  public static void main(String a[])throws Exception
  {
Class.forName("oracle.jdbc.driver.OracleDriver");
Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","manager");
Statement stmt=con.createStatement();
 Scanner sc=new Scanner(System.in); 
String s="yes";
while(s.equals("yes"))
{
    System.out.println("Enter Id Number");
    int id=sc.nextInt();
    ResultSet rs=stmt.executeQuery("select * from student");
    while(rs.next())
    {
      if(id==(rs.getInt(1)))
       {
        System.out.println("Enter name");
	String n=sc.next();
	System.out.println("Enter email");
	String e=sc.next();
	System.out.println("Enter Date of birth");
	String d=sc.next();
	Statement stmt1=con.createStatement();
        PreparedStatement pstmt=con.prepareStatement("update student set student_Name=?,email=?,Date_of_Birth=?  where student_id=?");
	pstmt.setString(1,n);
	pstmt.setString(2,e);
	pstmt.setString(3,d);
        pstmt.setInt(4,id);
	pstmt.executeUpdate();
       }
     }
System.out.println("Do you want to continue to enter the details");
s=sc.next();
}
    con.close();
  }
}