import java.sql.*;
import java.util.*;
class Inlab4_1
{
  public static void main(String args[])throws Exception
  {
    Class.forName("oracle.jdbc.driver.OracleDriver");
    Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","manager");
    Statement stmt=con.createStatement();
    stmt.executeUpdate("create table sales(itemid number,itemname varchar2(15),cost number)");
    Scanner sc=new Scanner(System.in);
    System.out.println("Enter Number of Items :");
   int n=sc.nextInt();
   for(int i=0;i<n;i++)
  {
   System.out.println("Enter item ID ");
   int itemid=sc.nextInt();
   System.out.println("Enter item Name ");
   String itemname=sc.next();
   System.out.println("Enter Cost ");
   int cost=sc.nextInt();

 PreparedStatement pstmt=con.prepareStatement("insert into sales values(?,?,?)");
   pstmt.setInt(1,itemid);
   pstmt.setString(2,itemname);
   pstmt.setInt(3,cost);
   pstmt.executeUpdate();
  }
int sum=0;
ResultSet rs1=stmt.executeQuery("select sum(cost) from sales");
while(rs1.next())
{
int a=rs1.getInt(1);
sum=sum+a;
System.out.println(" Total cost is"+a);
}
System.out.println("List of Items are ");
ResultSet rs=stmt.executeQuery("select itemname from sales ");
while(rs.next())
{
System.out.println(""+rs.getString(1));
}
 stmt.close();
    con.close();
  }
}