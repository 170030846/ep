import java.sql.*;
import java.io.*;
class Postlab4_2
{
public static void main(String args[]) throws Exception
{
Class.forName("oracle.jdbc.driver.OracleDriver");
Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","manager");
PreparedStatement pstmt=con.prepareStatement("select * from amazon");
ResultSet rs=pstmt.executeQuery();
while(rs.next())
{
String sr=rs.getString(1);
String st=rs.getString(2);
if(st.equals("animal")){
Blob b=rs.getBlob(3);
byte [] ar=b.getBytes(1,(int)b.length());
FileOutputStream fos=new FileOutputStream("C:\\Users\\Dell\\Desktop\\Animals\\"+sr+".jpg");
fos.write(ar);
fos.close();
//FOR FILE
int i;
Clob c=rs.getClob(4);
Reader r=c.getCharacterStream();
FileWriter fw=new FileWriter("C:\\Users\\Dell\\Desktop\\Animals\\"+sr+".txt");
while((i=r.read())!=-1)
fw.write((char)i);
fw.close();
}

else
{
Blob b=rs.getBlob(3);
byte [] ar=b.getBytes(1,(int)b.length());
FileOutputStream fos=new FileOutputStream("C:\\Users\\Dell\\Desktop\\Plants\\"+sr+".jpg");
fos.write(ar);
fos.close();



int j;
Clob c=rs.getClob(4);
Reader r=c.getCharacterStream();
FileWriter fw=new FileWriter("C:\\Users\\Dell\\Desktop\\Plants\\"+sr+".txt");
while((j=r.read())!=-1)
fw.write((char)j);
fw.close();
}
}
con.close();
}
}