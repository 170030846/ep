import java.sql.*;
import java.util.*;
class Prelab4_3A

{
  public static void main(String a[]) throws Exception
  {
    Class.forName("oracle.jdbc.driver.OracleDriver");
    Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","manager");
    Statement stmt=con.createStatement(); 
    Scanner sc=new Scanner(System.in);
 stmt.executeUpdate("create table users(uname varchar2(20),pwd varchar2(20))");
   System.out.println("Enter number of rows ");
int n=sc.nextInt();
PreparedStatement pstmt= con.prepareStatement("insert into users values(?,?)");
for(int i=0;i<n;i++)
{
   System.out.println("Enter username ");
  pstmt.setString(1,sc.next());
     System.out.println("Enter password ");
 pstmt.setString(2,sc.next());
 pstmt.executeUpdate();
}
con.close();
}
}