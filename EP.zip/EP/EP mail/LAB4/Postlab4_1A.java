	import java.sql.*;
import java.util.*;
import java.io.*;
class Postlab4_1A
{
   public static void main(String args[])throws Exception
   {
      Driver drv=new oracle.jdbc.driver.OracleDriver();
      DriverManager.registerDriver(drv);
      Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","manager");
  PreparedStatement pstmt=con.prepareStatement("insert into amazon values(?,?,?,?)");
         Scanner sc=new Scanner(System.in);
      System.out.println("Enter number of records:");
      int n=sc.nextInt();
      for(int i=0;i<n;i++)
      {
          System.out.println("Enter name:");
          String name=sc.next()+sc.nextLine();
          System.out.println("Enter category:");
          String category=sc.next()+sc.nextLine();
          System.out.println("Enter image path:");
          String image=sc.next()+sc.nextLine();
          System.out.println("Enter file  path:");
          String filepath=sc.next()+sc.nextLine(); 
          pstmt.setString(1,name);
          pstmt.setString(2,category);
          File f=new File(image);
          FileInputStream fis=new FileInputStream(f); 
          pstmt.setBinaryStream(3,fis,(int)f.length());
          File f1=new File(filepath);
          FileReader fis1=new FileReader(f1);
          pstmt.setCharacterStream(4,fis1,(int)f1.length());
          pstmt.executeUpdate();
      }
     
   }
}