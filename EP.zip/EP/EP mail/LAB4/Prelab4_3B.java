import java.sql.*;
import java.util.*;
class Prelab4_3B
{
  public static void main(String a[])throws Exception
  {
    Scanner s=new Scanner(System.in); 
    System.out.println("Enter user name");
    String uname=s.next();
    System.out.println("Enter password");
    String pwd=s.next();
    Class.forName("oracle.jdbc.driver.OracleDriver");
    Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","manager");
    Statement stmt=con.createStatement(); 
    ResultSet rs=stmt.executeQuery("select * from users");
    int flag=0;	
    while(rs.next())
    {
      if(uname.equals(rs.getString(1))&&pwd.equals(rs.getString(2)))
       {
          flag=1;
          break;
       }
     }
     if(flag==0)
       System.out.println("Invalid user");
    else
       System.out.println("Valid user");
    con.close();
  }
}


