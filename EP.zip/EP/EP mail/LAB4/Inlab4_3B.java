import java.sql.*;
import java.util.*;
class Inlab4_3B
{
public static void main(String [] args) throws Exception
{
Class.forName("oracle.jdbc.driver.OracleDriver");
Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","manager");
Statement stmt=con.createStatement();
stmt.executeUpdate("update workshop set name=(select student_name from student where student.student_id=workshop.id),email=(select email from student where student.student_id=workshop.id)");
stmt.close();
con.close();
}
}
