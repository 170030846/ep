import java.sql.*;
import java.util.*;
class Inlab4_2B
{
public static void main(String args[]) throws Exception
{
Class.forName("oracle.jdbc.driver.OracleDriver");
Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","manager");
 Scanner sc=new Scanner(System.in);
String s="yes";
while(s.equals("yes"))
{
System.out.println("Enter the ID number");
int student_id =sc.nextInt();
PreparedStatement pstmt=con.prepareStatement("insert into student(student_id) values(?)");
pstmt.setInt(1,student_id);
pstmt.executeUpdate();
System.out.println("Do you want to enter the ID Number ");
s=sc.next();
}
con.close();
}
}










