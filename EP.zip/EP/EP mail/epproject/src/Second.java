import java.io.*;  
import javax.servlet.*;  
import javax.servlet.http.*;  
  
public class Second extends HttpServlet {  
  
    public void doPost(HttpServletRequest request, HttpServletResponse response)  
        throws ServletException, IOException {  
  
    response.setContentType("text/html");  
    PrintWriter out = response.getWriter();  
       RequestDispatcher rd=request.getRequestDispatcher("/dashboard.html");  
        rd.forward(request, response);  
    }  
  
}  