import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class Skill5 extends HttpServlet
{
	public void service(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
               {
		   PrintWriter out=res.getWriter();
                    res.setContentType("text/html");
                   
                 try{
		
                    String Username=req.getParameter("user");
                    String pwd=req.getParameter("pwd");
                  
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","manager");
                       Statement stmt=con.createStatement();

                     ResultSet rs=stmt.executeQuery("select * from TeamHead");
                     int flag=0;
                     while(rs.next())
                     {
                      if(Username.equals(rs.getString(3))&&pwd.equals(rs.getString(4)))
                        {
                        flag=1;
                         break;
                         }
                     } 
                   if(flag==0)
                   out.println("Inavlid Login");

                  else
                  {out.println("Login Successfull");
     con.close();
  }
catch(Exception e){
			out.println(e);
		}
	}
}
