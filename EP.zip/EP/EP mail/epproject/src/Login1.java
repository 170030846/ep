import java.io.*;  
import javax.servlet.*;  
import javax.servlet.http.*;  
import java.sql.*;
public class Login1 extends HttpServlet {  
public void doPost(HttpServletRequest request, HttpServletResponse response)  
        throws ServletException, IOException {  
  
    response.setContentType("text/html");  
    PrintWriter out = response.getWriter();  
          try{
    String n=request.getParameter("user");  
    String p=request.getParameter("pwd");  
Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","manager");
                       Statement stmt=con.createStatement();

                     ResultSet rs=stmt.executeQuery("select * from Registeredmembers");
                     int flag=0;
                     while(rs.next())
                     {
                      if(n.equals(rs.getString(1))&&p.equals(rs.getString(3)))
                        {
                        flag=1;
                         break;
                         }
                     } 
        if(flag==1){  
        RequestDispatcher rd=request.getRequestDispatcher("/dashboard1.html");  
        rd.include(request, response);  
    }  
    else{  
        out.print("Sorry UserName or Password Error!");  
        RequestDispatcher rd=request.getRequestDispatcher("/index1.html");  
        rd.forward(request, response);  
             }         
        }  
catch(Exception e){
out.println(e);
    }  
  }
}  
