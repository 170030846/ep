import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class Prelab6_s3 extends HttpServlet
{
public void service(HttpServletRequest req,HttpServletResponse res)
{
try
{
PrintWriter out=res.getWriter();
ServletContext context=getServletContext();
ServletConfig config =getServletConfig();
String uname3=config.getInitParameter("uname3");
String pwd3=config.getInitParameter("pwd3");
out.println(context.getInitParameter("url"));
out.println("Username is" +uname3+"password is "+pwd3);
}
catch (Exception e)
{
System.out.println(e);
}
}
}