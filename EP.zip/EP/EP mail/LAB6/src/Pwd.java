import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
public class Pwd extends HttpServlet
{
public void service(HttpServletRequest req,HttpServletResponse res)
{

try
{
PrintWriter out=res.getWriter();
	String st=req.getParameter("pwd");
	int u=0,l=0,n=0;
    	char ch;
	int len=st.length();
    	for(int i=0;i <len;i++) 
	{
        ch = st.charAt(i);
        if( Character.isDigit(ch)) 
	{
	n++;
        }
        else if (Character.isUpperCase(ch)) 
	{
	u++;
        } 
	else if (Character.isLowerCase(ch)) 
	{
	l++;
    	}
   	}
	if(n==len)
	{
	RequestDispatcher rd=req.getRequestDispatcher("inlab1req1");
	rd.forward(req,res);
	}
	if(u==len)
	{
	RequestDispatcher rd=req.getRequestDispatcher("inlab1req2");
	rd.forward(req,res);
	}
	if(l==len)
	{
	RequestDispatcher rd=req.getRequestDispatcher("inlab1req3");
	rd.forward(req,res);
	}
	
	//out.println("ggg"+l);
}
catch(Exception e)
{
	System.out.println(e);
}
}
}