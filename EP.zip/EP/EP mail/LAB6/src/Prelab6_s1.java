import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class Prelab6_s1 extends HttpServlet
{
public void service(HttpServletRequest req,HttpServletResponse res)
{
try
{
PrintWriter out=res.getWriter();
ServletContext context=getServletContext();
ServletConfig config =getServletConfig();
String uname1=config.getInitParameter("uname1");
String pwd1=config.getInitParameter("pwd1");
out.println(context.getInitParameter("url"));
out.println("Username is" +uname1+"password is "+pwd1);
}
catch (Exception e)
{
System.out.println(e);
}
}
}