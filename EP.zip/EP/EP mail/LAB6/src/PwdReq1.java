import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
public class PwdReq1 extends HttpServlet
{
public void service(HttpServletRequest req,HttpServletResponse res)
{
try
{
	PrintWriter out=res.getWriter();
	out.println("The password is very weak!!");
}
catch(Exception e)
{
	System.out.println(e);
}
}
}