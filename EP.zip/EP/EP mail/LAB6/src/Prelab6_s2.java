import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class Prelab6_s2 extends HttpServlet
{
public void service(HttpServletRequest req,HttpServletResponse res)
{
try
{
PrintWriter out=res.getWriter();
ServletContext context=getServletContext();
ServletConfig config =getServletConfig();
String uname2=config.getInitParameter("uname2");
String pwd2=config.getInitParameter("pwd2");
out.println(context.getInitParameter("url"));
out.println("Username is" +uname2+"password is "+pwd2);
}
catch (Exception e)
{
System.out.println(e);
}
}
}