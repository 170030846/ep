import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
public class PwdReq3 extends HttpServlet
{
public void service(HttpServletRequest req,HttpServletResponse res)
{
try
{
	PrintWriter out=res.getWriter();
	out.println("The password must contain at least one uppercase and number in it");
}
catch(Exception e)
{
	System.out.println(e);
}
}
}