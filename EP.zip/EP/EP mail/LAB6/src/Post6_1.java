import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
public class Post6_1 extends HttpServlet
{
public void service(HttpServletRequest req,HttpServletResponse res)
{

try
{
Class.forName("oracle.jdbc.driver.OracleDriver");
Connection con= DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","manager");
Statement stmt=con.createStatement();
ResultSet rs=stmt.executeQuery("select * from post");
while(rs.next())
{
String s=rs.getString(1);
res.sendRedirect("https://www.google.com#q="+s);
}
}
catch (Exception e)
{
System.out.println(e);
}
}
}