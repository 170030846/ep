import javax.servlet.http.*;
import java.io.*;
import javax.servlet.*;

public class Date2 extends GenericServlet
{
public void service(ServletRequest req, ServletResponse res) throws IOException, ServletException
{
  PrintWriter out=res.getWriter();
try
{
      
   	String d= (String)req.getAttribute("count");
	out.println(d);
}
catch(Exception e)
{
out.println(e);
}
}

}

