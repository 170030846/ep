import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
public class StuResult1 extends HttpServlet
{
public void service(HttpServletRequest req,HttpServletResponse res)
{
try
{
int c=0;
PrintWriter out=res.getWriter();
ServletConfig config=getServletConfig();
ServletContext context=getServletContext();
if(config.getInitParameter("answer1").equals(context.getInitParameter("orginal1")))
c++;
if(config.getInitParameter("answer2").equals(context.getInitParameter("orginal2")))
c++;
if(config.getInitParameter("answer3").equals(context.getInitParameter("orginal3")))
c++;
if(config.getInitParameter("answer4").equals(context.getInitParameter("orginal4")))
c++;
if(config.getInitParameter("answer5").equals(context.getInitParameter("orginal5")))
c++;
req.setAttribute("count",c);
RequestDispatcher rd=req.getRequestDispatcher("Result");
rd.forward(req,res);
//out.println("Total Marks="+c);
}
catch(Exception e)
{
System.out.println(e);
}
}
}