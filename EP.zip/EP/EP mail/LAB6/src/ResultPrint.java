import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
public class ResultPrint extends HttpServlet
{
public void service(HttpServletRequest req,HttpServletResponse res)
{
try
{
PrintWriter out=res.getWriter();
Integer c=(Integer)req.getAttribute("count");

out.println("Totalmarks"+c);
}
catch(Exception e)
{
System.out.println(e);
}
}
}
