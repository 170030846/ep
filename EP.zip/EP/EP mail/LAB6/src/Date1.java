import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
import java.util.*;
public class Date1 extends HttpServlet
{
public void service(HttpServletRequest req,HttpServletResponse res)
{
try
{	
	java.util.Date date = new java.util.Date();
	String s=date.toString();
	req.setAttribute("count",s);
	RequestDispatcher rd=req.getRequestDispatcher("pre3");
	rd.forward(req,res);
}
catch(Exception e)
{
	System.out.println(e);
}
}
}