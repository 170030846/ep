import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
public class Student1 extends HttpServlet
{
     public void service(HttpServletRequest req,HttpServletResponse res)throws IOException
     {
	PrintWriter out=res.getWriter();
	ServletContext context=getServletContext();
	String url=context.getInitParameter("url");
	out.println(url);
	ServletConfig config=getServletConfig();
	String uname=config.getInitParameter("uname1");
	out.println(uname);
	String pwd=config.getInitParameter("pwd1");
	out.println(pwd);
     }
}